package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Employee;
import com.example.demo.entities.Employee_card_details;
import com.example.demo.service.EmployeeCardDetailsService;

import jakarta.validation.Valid;


@RestController
@CrossOrigin
@RequestMapping("/api/carddetails")
public class EmployeeCardDetailsController {

	@Autowired
	private EmployeeCardDetailsService employeeCardDetailsService;
	
	@PostMapping
	public ResponseEntity<Employee_card_details> addCardDetails(@Valid @RequestBody Employee_card_details employeeCardDetails){
		
		Employee_card_details ecd = employeeCardDetailsService.addCardDetails(employeeCardDetails);
		
		return new ResponseEntity<Employee_card_details>(ecd,HttpStatus.CREATED);
	}
	@GetMapping
	public List<Employee_card_details> getAllDetails(){
		return employeeCardDetailsService.getAll();
	}
}
