package com.example.demo.entities;

import java.time.LocalDate;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@EnableAutoConfiguration
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "employee_card_details")
public class Employee_card_details {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int loan_id;
//	private int employee_id;
	
	private LocalDate card_issue_date;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="emp_id")
	private Employee employee;
}
