package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Employee_card_details;

public interface EmployeeCardDetailsRepository extends JpaRepository<Employee_card_details, Integer>{
//	Employee_card_details findByEmp_Id(int empId);

}
