package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Employee;
import com.example.demo.entities.Employee_card_details;
import com.example.demo.repositories.EmployeeCardDetailsRepository;

@Service
public class EmployeeCardDetailsServiceImpl implements EmployeeCardDetailsService{

	@Autowired
	private EmployeeCardDetailsRepository employeeCardDetailsRepository;
	
	public Employee_card_details addCardDetails(Employee_card_details employee_card_details) {
		// TODO Auto-generated method stub
		return employeeCardDetailsRepository.save(employee_card_details);
//		return new ResponseEntity<Employee_card_details>(employee_card_details, HttpStatus.CREATED);
	}
	
	@Override
	public List<Employee_card_details> getAll() {
		// TODO Auto-generated method stub
		return employeeCardDetailsRepository.findAll();
	}

}
