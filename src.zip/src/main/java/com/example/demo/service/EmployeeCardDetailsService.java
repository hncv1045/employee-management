package com.example.demo.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.demo.entities.Employee_card_details;

public interface EmployeeCardDetailsService {

	Employee_card_details addCardDetails(Employee_card_details employee_card_details);

	List<Employee_card_details> getAll();
}
